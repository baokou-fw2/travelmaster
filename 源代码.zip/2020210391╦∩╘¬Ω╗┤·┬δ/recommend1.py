# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'recommend.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import numpy

from PyQt5.QtWidgets import QMessageBox


class directon:
    def __init__(self):
        self.edit=0
        self.score =0
        self.city='ss'
        self.landscape=0
        self.fee=0
        self.transport=0
        self.live=0
        self.food=0
class quan:
    def __init__(self):
        self.landscape = 0
        self.fee = 0
        self.transport = 0
        self.live = 0
        self.food = 0


class Ui_MainWindow(QtCore.QObject):#不要忘了引入核心和自定义消息
    switch_window3 = QtCore.pyqtSignal()
    dir1 =directon()#五个目的地的结构变量
    dir2 = directon()
    dir3 = directon()
    dir4 = directon()
    dir5 = directon()
    zonghe=[dir1,dir2,dir3,dir4,dir5]#五个目的地组成的数组
    quanzhi=[1,1,1,1,1]#权值初始化
    count=0#城市数量计数


    def setupUi(self, MainWindow):

        MainWindow.setObjectName("目的地科学评价")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.gridLayoutWidget.setGeometry(QtCore.QRect(210, 30, 368, 331))
        self.gridLayoutWidget.setObjectName("gridLayoutWidget")
        self.gridLayout = QtWidgets.QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.city2 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.city2.setObjectName("city2")
        self.gridLayout.addWidget(self.city2, 0, 3, 1, 1)
        self.fee2 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.fee2.setObjectName("fee2")
        self.gridLayout.addWidget(self.fee2, 4, 3, 1, 1)
        self.fee1 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.fee1.setObjectName("fee1")
        self.gridLayout.addWidget(self.fee1, 4, 2, 1, 1)
        self.city1 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.city1.setObjectName("city1")
        self.gridLayout.addWidget(self.city1, 0, 2, 1, 1)
        self.landscape2 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.landscape2.setObjectName("landscape2")
        self.gridLayout.addWidget(self.landscape2, 1, 3, 1, 1)
        self.city = QtWidgets.QLabel(self.gridLayoutWidget)
        self.city.setObjectName("city")
        self.gridLayout.addWidget(self.city, 0, 1, 1, 1)
        self.city3 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.city3.setObjectName("city3")
        self.gridLayout.addWidget(self.city3, 0, 4, 1, 1)
        self.transport = QtWidgets.QLabel(self.gridLayoutWidget)
        self.transport.setObjectName("transport")
        self.gridLayout.addWidget(self.transport, 2, 1, 1, 1)
        self.food = QtWidgets.QLabel(self.gridLayoutWidget)
        self.food.setObjectName("food")
        self.gridLayout.addWidget(self.food, 3, 1, 1, 1)
        self.landscape3 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.landscape3.setObjectName("landscape3")
        self.gridLayout.addWidget(self.landscape3, 1, 4, 1, 1)
        self.food1 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.food1.setObjectName("food1")
        self.gridLayout.addWidget(self.food1, 3, 2, 1, 1)
        self.landscape = QtWidgets.QLabel(self.gridLayoutWidget)
        self.landscape.setObjectName("landscape")
        self.gridLayout.addWidget(self.landscape, 1, 1, 1, 1)
        self.live = QtWidgets.QLabel(self.gridLayoutWidget)
        self.live.setObjectName("live")
        self.gridLayout.addWidget(self.live, 5, 1, 1, 1)
        self.fee = QtWidgets.QLabel(self.gridLayoutWidget)
        self.fee.setObjectName("fee")
        self.gridLayout.addWidget(self.fee, 4, 1, 1, 1)
        self.transport1 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.transport1.setObjectName("transport1")
        self.gridLayout.addWidget(self.transport1, 2, 2, 1, 1)
        self.live1 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.live1.setObjectName("live1")
        self.gridLayout.addWidget(self.live1, 5, 2, 1, 1)
        self.live2 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.live2.setObjectName("live2")
        self.gridLayout.addWidget(self.live2, 5, 3, 1, 1)
        self.transport2 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.transport2.setObjectName("transport2")
        self.gridLayout.addWidget(self.transport2, 2, 3, 1, 1)
        self.food2 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.food2.setObjectName("food2")
        self.gridLayout.addWidget(self.food2, 3, 3, 1, 1)
        self.transport3 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.transport3.setObjectName("transport3")
        self.gridLayout.addWidget(self.transport3, 2, 4, 1, 1)
        self.food3 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.food3.setObjectName("food3")
        self.gridLayout.addWidget(self.food3, 3, 4, 1, 1)
        self.landscape1 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.landscape1.setObjectName("landscape1")
        self.gridLayout.addWidget(self.landscape1, 1, 2, 1, 1)
        self.landscape4 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.landscape4.setObjectName("landscape4")
        self.gridLayout.addWidget(self.landscape4, 1, 5, 1, 1)
        self.fee3 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.fee3.setObjectName("fee3")
        self.gridLayout.addWidget(self.fee3, 4, 4, 1, 1)
        self.food4 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.food4.setObjectName("food4")
        self.gridLayout.addWidget(self.food4, 3, 5, 1, 1)
        self.live3 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.live3.setObjectName("live3")
        self.gridLayout.addWidget(self.live3, 5, 4, 1, 1)
        self.fee4 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.fee4.setObjectName("fee4")
        self.gridLayout.addWidget(self.fee4, 4, 5, 1, 1)
        self.live4 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.live4.setObjectName("live4")
        self.gridLayout.addWidget(self.live4, 5, 5, 1, 1)
        self.transport4 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.transport4.setObjectName("transport4")
        self.gridLayout.addWidget(self.transport4, 2, 5, 1, 1)
        self.city4 = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.city4.setObjectName("city4")
        self.gridLayout.addWidget(self.city4, 0, 5, 1, 1)
        self.landscape_quan = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.landscape_quan.setObjectName("landscape_quan")
        self.gridLayout.addWidget(self.landscape_quan, 1, 0, 1, 1)
        self.transport_quan = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.transport_quan.setObjectName("transport_quan")
        self.gridLayout.addWidget(self.transport_quan, 2, 0, 1, 1)
        self.food_quan = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.food_quan.setObjectName("food_quan")
        self.gridLayout.addWidget(self.food_quan, 3, 0, 1, 1)
        self.fee_quan = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.fee_quan.setObjectName("fee_quan")
        self.gridLayout.addWidget(self.fee_quan, 4, 0, 1, 1)
        self.live_quan = QtWidgets.QLineEdit(self.gridLayoutWidget)
        self.live_quan.setObjectName("live_quan")
        self.gridLayout.addWidget(self.live_quan, 5, 0, 1, 1)
        self.label = QtWidgets.QLabel(self.gridLayoutWidget)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(290, 370, 210, 28))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(290, 440, 210, 28))
        self.pushButton.setObjectName("pushButton")
        self.result = QtWidgets.QLineEdit(self.centralwidget)
        self.result.setEnabled(False)
        self.result.setGeometry(QtCore.QRect(160, 410, 500, 21))
        self.result.setObjectName("result")
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(60, 30, 120, 80))
        self.groupBox.setFlat(True)
        self.groupBox.setObjectName("groupBox")
        self.widget = QtWidgets.QWidget(self.groupBox)
        self.widget.setGeometry(QtCore.QRect(10, 20, 93, 47))
        self.widget.setObjectName("widget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.widget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.is_quan = QtWidgets.QCheckBox(self.widget)
        self.is_quan.setObjectName("is_quan")
        self.verticalLayout.addWidget(self.is_quan)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        #修改界面时复制粘贴以上内容即可，不要忘了在下面也改一下

        self.retranslateUi(MainWindow)
        self.is_quan.toggled['bool'].connect(self.label.setHidden)
        self.is_quan.toggled['bool'].connect(self.landscape_quan.setHidden)
        self.is_quan.toggled['bool'].connect(self.transport_quan.setHidden)
        self.is_quan.toggled['bool'].connect(self.food_quan.setHidden)
        self.is_quan.toggled['bool'].connect(self.fee_quan.setHidden)
        self.is_quan.toggled['bool'].connect(self.live_quan.setHidden)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.pushButton_2.clicked.connect(self.getedit)#以下为添加的内容
        self.pushButton.clicked.connect(self.switch)
        #self.pushButton_3.clicked.connect(self.result)

    def switch(self):
        self.switch_window3.emit()
    def getedit(self):#添加清楚文本框内容的函数,后续如果想实现多功能转换可以加一个计算按钮和勾选框，然后按照所框选的计算方式调用函数
        self.dir1.city=self.city1.text()
        self.dir1.food = self.food1.text()
        self.dir1.landscape=self.landscape1.text()
        self.dir1.fee = self.fee1.text()
        self.dir1.live = self.live1.text()
        self.dir1.transport = self.transport1.text()


        self.dir2.city=self.city2.text()
        self.dir2.food = self.food2.text()
        self.dir2.landscape = self.landscape2.text()
        self.dir2.fee = self.fee2.text()
        self.dir2.live = self.live2.text()
        self.dir2.transport = self.transport2.text()

        self.dir3.city=self.city3.text()
        self.dir3.food = self.food3.text()
        self.dir3.landscape = self.landscape3.text()
        self.dir3.fee = self.fee3.text()
        self.dir3.live = self.live3.text()
        self.dir3.transport = self.transport3.text()

        self.dir4.city=self.city4.text()
        self.dir4.food = self.food4.text()
        self.dir4.landscape = self.landscape4.text()
        self.dir4.fee = self.fee4.text()
        self.dir4.live = self.live4.text()
        self.dir4.transport = self.transport4.text()



        city_count=0
        for j in range(4):
            if self.zonghe[j].city:
                self.zonghe[j].edit=1
                city_count=city_count+1
        city_list = numpy.zeros((city_count, 5))#创建一个四个城市五个指标的矩阵
        try:
            if self.is_quan.isChecked() == 0:
                self.quanzhi[0] = int(self.landscape_quan.text())
                self.quanzhi[1] = int(self.transport_quan.text())
                self.quanzhi[2] = int(self.food_quan.text())
                self.quanzhi[3] = int(self.fee_quan.text())
                self.quanzhi[4] = int(self.live_quan.text())
            for i in range(
                    city_count):
                if self.zonghe[i].edit:
                    city_list[i][0] = self.zonghe[i].landscape
                    city_list[i][1] = self.zonghe[i].transport
                    city_list[i][2] = self.zonghe[i].food
                    city_list[i][3] = self.zonghe[i].fee
                    city_list[i][4] = self.zonghe[i].live

            x = numpy.max(city_list)
            z=numpy.min(city_list)
            y = numpy.max(self.quanzhi)
            h=numpy.min(self.quanzhi)
            if x > 10 or y > 10 or z<=0 or h<=0:
                self.result.setText("请输入1-10的整数分数或权值")
            else:
                if self.is_quan.isChecked() == 1:
                    self.no_quan(city_list=city_list)#输出评价矩阵给无权值得计算函数
                elif self.is_quan.isChecked() == 0:
                    self.quan(city_list=city_list, quan=self.quanzhi, city_count=city_count)#输出评价矩阵给有权计算函数


        except ValueError or numpy.linalg.LinAlgError:#输入不正确的时候会报错
            self.result.setText("请输入完整")



    def no_quan(self,city_list):
        # 灰色关联分析法的实现
        city_list_perfect = [9, 9, 9, 9, 9]#最佳方案得分
        a1 = abs(city_list - city_list_perfect)  # 构建yk-xik
        max_a1 = numpy.max(a1, axis=1)#每一行的最大值
        max_max = numpy.max(max_a1, axis=0)  # 最大值中的最大值
        min_a1 = numpy.min(a1, axis=1)#每一行的最小值
        min_min = numpy.min(min_a1, axis=0)#最小值中的最小值
        connect_data = 10000 * (min_min + 0.5 * max_max) / (a1 + 0.5 * max_max)  # 计算关联系数
        connect_result = numpy.mean(connect_data, axis=1, dtype=int)  # 计算关联度
        self.result.setText("各目的地分数为："+str(connect_result/100))
    def quan(self,city_list,quan,city_count):
        #计算权重比矩阵：目标层-准则层
        compare_socre=numpy.transpose(self.max_eig(matrix=self.mat_creat(quan)))#各个层的矩阵
        #计算各个方案在各个指标的比：准则层-方案层
        martrix_city={'lanscape1':0,'transport1':0,'food1':0,'fee1':0,'live1':0}#用字典存储各个比较矩阵
        for i in range(5):#五个准则，取列向量
            martrix_city[i]=self.max_eig(matrix=self.mat_creat(city_list[:,i]))#取第i列,嵌套调用直接求特征向量，并归一化
        #求各层的归一化向量
        second_score=numpy.zeros((city_count,5))
        for i in range(5):
            second_score[:,i]=martrix_city[i]#把字典变成数组，准则层-方案层的权向量矩阵
        #矩阵相乘求各个方案的分数
        end_score=numpy.zeros((1,city_count))
        for i in range(city_count):
            for j in range(5):
                end_score[0][i]=end_score[0][i]+second_score[i][j]*compare_socre[j]
        total=numpy.sum(end_score)#总分数
        end_score=10000*end_score/total#把分数归一化
        end_score=abs(end_score.astype(int))#得到百分制的分数
        self.result.setText("最后分数为："+str(end_score/100))


    def mat_creat(self,array_score):#计算矩阵

        length_arry=len(array_score)#计算需要多大的矩阵
        matrix=numpy.zeros((length_arry,length_arry))
        for i in range(length_arry):
            for j in range(length_arry):
                matrix[i][j]=array_score[i]/array_score[j]
        return matrix
    def max_eig(self,matrix):
        lamda = numpy.linalg.eig(matrix)
        index = numpy.argmax(lamda[0])
        vector = lamda[1][:, index]
        vector_final = numpy.transpose((numpy.real(vector)))
        return vector_final#返回最大特征值对应的特征向量

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "目的地科学评价"))
        self.city.setText(_translate("MainWindow", "请输入城市"))
        self.transport.setText(_translate("MainWindow", "交通"))
        self.food.setText(_translate("MainWindow", "饮食"))
        self.landscape.setText(_translate("MainWindow", "景色"))
        self.live.setText(_translate("MainWindow", "居住"))
        self.fee.setText(_translate("MainWindow", "费用"))
        self.label.setText(_translate("MainWindow", "权值"))
        self.pushButton_2.setText(_translate("MainWindow", "确认"))
        self.pushButton.setText(_translate("MainWindow", "主菜单"))
        self.groupBox.setTitle(_translate("MainWindow", "选择计算方式"))
        self.is_quan.setText(_translate("MainWindow", "无需加权"))

