# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'plan.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!
import json
import openpyxl
import sys
from PIL import Image
from io import BytesIO
import numpy
import requests
from PyQt5.QtCore import pyqtSlot,  QUrl
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWebEngineWidgets import *
from PyQt5 import QtWebEngineWidgets
from PyQt5.QtWidgets import QMessageBox,QTextEdit

#global map_road=[0]

class mudi:
    def __init__(self):
        self.xl=0
        self.yl=0
        self.name1="无"
        self.edit1=0
class Ui_MainWindow(QtCore.QObject):
    switch_window4 = QtCore.pyqtSignal()
    startk=mudi()#五个目的地和途径点
    des1k=mudi()
    des2k=mudi()
    des3k=mudi()
    endk=mudi()
    road_list=[0,0,0,0,0]#存放更新后的路径数组
    visition = [startk, des1k, des2k, des3k, endk]  # 存放各个目的地
    destination = [[0,0], [0,0], [0,0], [0,0], [0,0]]#保存url请求中的地址参数，经纬度
    city_namer=0#城市名称
    count_destination = 0#保存城市数量
    timelist=[[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]]#
    road_dic={'start':0,'end':0,'name':0,'time':0,'fee':0,'road':0}#创建一个保存A到B的路径字典
    def setupUi(self, MainWindow):
        self.clear()#如果页面非正常关闭点开时进行更新



        MainWindow.setObjectName("最短路线规划")
        MainWindow.setEnabled(True)
        MainWindow.resize(800, 600)
        MainWindow.setAutoFillBackground(False)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(11, 41, 93, 28))
        self.pushButton.setObjectName("pushButton")
        self.broswer = QtWebEngineWidgets.QWebEngineView(self.centralwidget)
        self.broswer.setGeometry(QtCore.QRect(100, 400, 1000, 500))
        self.broswer.setObjectName("broswer")
        self.broswer.load(QUrl('https://lbs.amap.com/tools/picker'))
        self.layoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.layoutWidget.setGeometry(QtCore.QRect(100, 120, 370, 196))
        self.layoutWidget.setObjectName("layoutWidget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.layoutWidget)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtWidgets.QLabel(self.layoutWidget)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.gridLayout_2 = QtWidgets.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.label_6 = QtWidgets.QLabel(self.layoutWidget)
        self.label_6.setObjectName("label_6")
        self.gridLayout_2.addWidget(self.label_6, 4, 0, 1, 1)
        self.label_3 = QtWidgets.QLabel(self.layoutWidget)
        self.label_3.setObjectName("label_3")
        self.gridLayout_2.addWidget(self.label_3, 1, 0, 1, 1)
        self.d3_X = QtWidgets.QLineEdit(self.layoutWidget)
        self.d3_X.setObjectName("d3_X")
        self.gridLayout_2.addWidget(self.d3_X, 3, 2, 1, 1)
        self.d1_X = QtWidgets.QLineEdit(self.layoutWidget)
        self.d1_X.setObjectName("d1_X")
        self.gridLayout_2.addWidget(self.d1_X, 1, 2, 1, 1)
        self.label_4 = QtWidgets.QLabel(self.layoutWidget)
        self.label_4.setObjectName("label_4")
        self.gridLayout_2.addWidget(self.label_4, 2, 0, 1, 1)
        self.label_5 = QtWidgets.QLabel(self.layoutWidget)
        self.label_5.setObjectName("label_5")
        self.gridLayout_2.addWidget(self.label_5, 3, 0, 1, 1)
        self.d2_X = QtWidgets.QLineEdit(self.layoutWidget)
        self.d2_X.setObjectName("d2_X")
        self.gridLayout_2.addWidget(self.d2_X, 2, 2, 1, 1)
        self.start_X = QtWidgets.QLineEdit(self.layoutWidget)
        self.start_X.setObjectName("start_X")
        self.gridLayout_2.addWidget(self.start_X, 0, 2, 1, 1)
        self.d3_Y = QtWidgets.QLineEdit(self.layoutWidget)
        self.d3_Y.setObjectName("d3_Y")
        self.gridLayout_2.addWidget(self.d3_Y, 3, 3, 1, 1)
        self.d1_Y = QtWidgets.QLineEdit(self.layoutWidget)
        self.d1_Y.setObjectName("d1_Y")
        self.gridLayout_2.addWidget(self.d1_Y, 1, 3, 1, 1)
        self.d2_Y = QtWidgets.QLineEdit(self.layoutWidget)
        self.d2_Y.setObjectName("d2_Y")
        self.gridLayout_2.addWidget(self.d2_Y, 2, 3, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.layoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout_2.addWidget(self.label_2, 0, 0, 1, 1)
        self.start_Y = QtWidgets.QLineEdit(self.layoutWidget)
        self.start_Y.setObjectName("start_Y")
        self.gridLayout_2.addWidget(self.start_Y, 0, 3, 1, 1)
        self.start = QtWidgets.QLineEdit(self.layoutWidget)
        self.start.setObjectName("start")
        self.gridLayout_2.addWidget(self.start, 0, 1, 1, 1)
        self.des1 = QtWidgets.QLineEdit(self.layoutWidget)
        self.des1.setObjectName("des1")
        self.gridLayout_2.addWidget(self.des1, 1, 1, 1, 1)
        self.des2 = QtWidgets.QLineEdit(self.layoutWidget)
        self.des2.setObjectName("des2")
        self.gridLayout_2.addWidget(self.des2, 2, 1, 1, 1)
        self.des3 = QtWidgets.QLineEdit(self.layoutWidget)
        self.des3.setObjectName("des3")
        self.gridLayout_2.addWidget(self.des3, 3, 1, 1, 1)
        self.end = QtWidgets.QLineEdit(self.layoutWidget)
        self.end.setObjectName("end")
        self.gridLayout_2.addWidget(self.end, 4, 1, 1, 1)
        self.end_X = QtWidgets.QLineEdit(self.layoutWidget)
        self.end_X.setObjectName("end_X")
        self.gridLayout_2.addWidget(self.end_X, 4, 2, 1, 1)
        self.end_Y = QtWidgets.QLineEdit(self.layoutWidget)
        self.end_Y.setObjectName("end_Y")
        self.gridLayout_2.addWidget(self.end_Y, 4, 3, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout_2)
        self.verticalLayout_2.addLayout(self.verticalLayout)
        self.OK = QtWidgets.QPushButton(self.layoutWidget)
        self.OK.setObjectName("OK")
        self.verticalLayout_2.addWidget(self.OK)
        self.cityname = QtWidgets.QLabel(self.centralwidget)
        self.cityname.setGeometry(QtCore.QRect(100, 100, 72, 15))
        self.cityname.setObjectName("cityname")
        self.city_name = QtWidgets.QLineEdit(self.centralwidget)
        self.city_name.setGeometry(QtCore.QRect(150, 100, 113, 21))
        self.city_name.setObjectName("city_name")
        self.result = QtWidgets.QLineEdit(self.centralwidget)
        self.result.setEnabled(False)
        self.result.setGeometry(QtCore.QRect(120, 40, 361, 51))
        self.result.setMaximumSize(QtCore.QSize(16777215, 16777215))
        self.result.setObjectName("result")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(490, 190, 221, 101))
        self.label_7.setObjectName("label_7")
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(500, 40, 101, 80))
        self.groupBox.setFlat(True)
        self.groupBox.setObjectName("groupBox")
        self.self_drive = QtWidgets.QCheckBox(self.groupBox)
        self.self_drive.setGeometry(QtCore.QRect(10, 60, 57, 19))
        self.self_drive.setObjectName("self_drive")
        self.public_transit = QtWidgets.QCheckBox(self.groupBox)
        self.public_transit.setGeometry(QtCore.QRect(10, 34, 91, 19))
        self.public_transit.setObjectName("public_transit")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        MainWindow.setObjectName("MainWindow")
        MainWindow.setEnabled(True)
        MainWindow.resize(800, 600)
        MainWindow.setAutoFillBackground(False)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(11, 41, 93, 28))
        self.pushButton.setObjectName("pushButton")
        self.broswer = QtWebEngineWidgets.QWebEngineView(self.centralwidget)
        self.broswer.setGeometry(QtCore.QRect(100, 400, 1000, 500))
        self.broswer.setObjectName("broswer")
        self.broswer.load(QUrl('https://lbs.amap.com/tools/picker'))
        self.layoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.layoutWidget.setGeometry(QtCore.QRect(100, 120, 370, 196))
        self.layoutWidget.setObjectName("layoutWidget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.layoutWidget)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtWidgets.QLabel(self.layoutWidget)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.gridLayout_2 = QtWidgets.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.label_6 = QtWidgets.QLabel(self.layoutWidget)
        self.label_6.setObjectName("label_6")
        self.gridLayout_2.addWidget(self.label_6, 4, 0, 1, 1)
        self.label_3 = QtWidgets.QLabel(self.layoutWidget)
        self.label_3.setObjectName("label_3")
        self.gridLayout_2.addWidget(self.label_3, 1, 0, 1, 1)
        self.d3_X = QtWidgets.QLineEdit(self.layoutWidget)
        self.d3_X.setObjectName("d3_X")
        self.gridLayout_2.addWidget(self.d3_X, 3, 2, 1, 1)
        self.d1_X = QtWidgets.QLineEdit(self.layoutWidget)
        self.d1_X.setObjectName("d1_X")
        self.gridLayout_2.addWidget(self.d1_X, 1, 2, 1, 1)
        self.label_4 = QtWidgets.QLabel(self.layoutWidget)
        self.label_4.setObjectName("label_4")
        self.gridLayout_2.addWidget(self.label_4, 2, 0, 1, 1)
        self.label_5 = QtWidgets.QLabel(self.layoutWidget)
        self.label_5.setObjectName("label_5")
        self.gridLayout_2.addWidget(self.label_5, 3, 0, 1, 1)
        self.d2_X = QtWidgets.QLineEdit(self.layoutWidget)
        self.d2_X.setObjectName("d2_X")
        self.gridLayout_2.addWidget(self.d2_X, 2, 2, 1, 1)
        self.start_X = QtWidgets.QLineEdit(self.layoutWidget)
        self.start_X.setObjectName("start_X")
        self.gridLayout_2.addWidget(self.start_X, 0, 2, 1, 1)
        self.d3_Y = QtWidgets.QLineEdit(self.layoutWidget)
        self.d3_Y.setObjectName("d3_Y")
        self.gridLayout_2.addWidget(self.d3_Y, 3, 3, 1, 1)
        self.d1_Y = QtWidgets.QLineEdit(self.layoutWidget)
        self.d1_Y.setObjectName("d1_Y")
        self.gridLayout_2.addWidget(self.d1_Y, 1, 3, 1, 1)
        self.d2_Y = QtWidgets.QLineEdit(self.layoutWidget)
        self.d2_Y.setObjectName("d2_Y")
        self.gridLayout_2.addWidget(self.d2_Y, 2, 3, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.layoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout_2.addWidget(self.label_2, 0, 0, 1, 1)
        self.start_Y = QtWidgets.QLineEdit(self.layoutWidget)
        self.start_Y.setObjectName("start_Y")
        self.gridLayout_2.addWidget(self.start_Y, 0, 3, 1, 1)
        self.start = QtWidgets.QLineEdit(self.layoutWidget)
        self.start.setObjectName("start")
        self.gridLayout_2.addWidget(self.start, 0, 1, 1, 1)
        self.des1 = QtWidgets.QLineEdit(self.layoutWidget)
        self.des1.setObjectName("des1")
        self.gridLayout_2.addWidget(self.des1, 1, 1, 1, 1)
        self.des2 = QtWidgets.QLineEdit(self.layoutWidget)
        self.des2.setObjectName("des2")
        self.gridLayout_2.addWidget(self.des2, 2, 1, 1, 1)
        self.des3 = QtWidgets.QLineEdit(self.layoutWidget)
        self.des3.setObjectName("des3")
        self.gridLayout_2.addWidget(self.des3, 3, 1, 1, 1)
        self.end = QtWidgets.QLineEdit(self.layoutWidget)
        self.end.setObjectName("end")
        self.gridLayout_2.addWidget(self.end, 4, 1, 1, 1)
        self.end_X = QtWidgets.QLineEdit(self.layoutWidget)
        self.end_X.setObjectName("end_X")
        self.gridLayout_2.addWidget(self.end_X, 4, 2, 1, 1)
        self.end_Y = QtWidgets.QLineEdit(self.layoutWidget)
        self.end_Y.setObjectName("end_Y")
        self.gridLayout_2.addWidget(self.end_Y, 4, 3, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout_2)
        self.verticalLayout_2.addLayout(self.verticalLayout)
        self.OK = QtWidgets.QPushButton(self.layoutWidget)
        self.OK.setObjectName("OK")
        self.verticalLayout_2.addWidget(self.OK)
        self.cityname = QtWidgets.QLabel(self.centralwidget)
        self.cityname.setGeometry(QtCore.QRect(100, 100, 72, 15))
        self.cityname.setObjectName("cityname")
        self.city_name = QtWidgets.QLineEdit(self.centralwidget)
        self.city_name.setGeometry(QtCore.QRect(150, 100, 113, 21))
        self.city_name.setObjectName("city_name")
        self.result = QtWidgets.QTextEdit(self.centralwidget)
        self.result.setGeometry(QtCore.QRect(120, 40, 361, 51))
        self.result.setMaximumSize(QtCore.QSize(16777215, 16777215))
        self.result.setObjectName("result")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(490, 190, 221, 101))
        self.label_7.setObjectName("label_7")
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(500, 40, 101, 80))
        self.groupBox.setFlat(True)
        self.groupBox.setObjectName("groupBox")
        self.self_drive = QtWidgets.QCheckBox(self.groupBox)
        self.self_drive.setGeometry(QtCore.QRect(10, 60, 57, 19))
        self.self_drive.setObjectName("self_drive")
        self.public_transit = QtWidgets.QCheckBox(self.groupBox)
        self.public_transit.setGeometry(QtCore.QRect(10, 34, 91, 19))
        self.public_transit.setObjectName("public_transit")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        #界面修改分割线---------------------------------------------------------------------------
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.pushButton.clicked.connect(self.switch)
        self.OK.clicked.connect(self.getpoi)
    def switch(self):
        self.switch_window4.emit()
    def getpoi(self):
        self.clear()
        self.city_namer=self.city_name.text()

        self.startk.xl=self.start_X.text()
        self.startk.yl=self.start_Y.text()
        self.startk.name1=self.start.text()

        self.des1k.xl = self.d1_X.text()
        self.des1k.yl = self.d1_Y.text()
        self.des1k.name1 = self.des1.text()

        self.des2k.xl = self.d2_X.text()
        self.des2k.yl = self.d2_Y.text()
        self.des2k.name1 = self.des2.text()

        self.des3k.xl = self.d3_X.text()
        self.des3k.yl = self.d3_Y.text()
        self.des3k.name1 = self.des3.text()

        self.endk.xl = self.end_X.text()
        self.endk.yl = self.end_Y.text()
        self.endk.name1 = self.end.text()

        for j in range(5):
            if self.visition[j].name1:#只有名称输入后才能继续赋值
                self.visition[j].edit1=1
        check_both=self.public_transit.isChecked() and self.self_drive.isChecked()#避免勾选两个
        for i in range(5):
            if self.visition[i].edit1:
                self.destination[i] = [self.visition[i].xl, self.visition[i].yl]
                self.count_destination=self.count_destination+1#计算需要一个多大的矩阵
        if self.count_destination == 0 or self.count_destination == 1 or self.city_namer==0:
            self.result.setText("请输入城市名称或足够的目的地数量")
        else:
            if check_both:
                self.result.setText("请勾选单一的交通方式")
            elif self.public_transit.isChecked()==1:
                self.public_transit_fun()
            elif self.self_drive.isChecked()==1:
                self.self_drive_fun()
            else:
                self.result.setText("请勾选交通方式")
    def self_drive_fun(self):
        time_list = numpy.zeros([self.count_destination, self.count_destination])
        self.creat_word()#创建一个新的excel
        ok_number=0
        key = ['a0ea2f87d4e3eb6d68c660ad7774f579']
        try:
            for i in range(self.count_destination):
                ok_number = 0
                for j in range(self.count_destination):
                    if j != i:
                        parameters = {'key': key[0], 'origin': self.destination[i][0] + ',' + self.destination[i][1],
                                      'destination': self.destination[j][0] + ',' + self.destination[j][1]}
                        res = requests.get('https://restapi.amap.com/v3/direction/driving?',
                                           params=parameters)
                        json_dic = json.loads(res.text)
                        if int(json_dic['status']) == 1:
                            ok_number = 1
                            if j != i:
                                time_list[i][j] = int(json_dic['route']['paths'][0]['duration'])  # 构造时间矩阵
                            else:
                                time_list[i][j] = 0  # numpy创建出的数组要改哪一行必须全改了不然就报错
            if ok_number == 1:
                self.road_calculate(time_list=time_list)  # 调用矩阵计算
            if ok_number == 0:
                self.result.setText("请按照要求输入经纬度或城市")
        except TypeError:
            self.result.setPlainText("请按顺序从上到下输入")





    def public_transit_fun(self):
        time_list = numpy.zeros([self.count_destination, self.count_destination])
        self.creat_word()
        ok_number=0#是否调用成功
        key = ['a0ea2f87d4e3eb6d68c660ad7774f579']
        try:
            for i in range(self.count_destination):
                ok_number = 0
                for j in range(self.count_destination):
                    parameters = {'key': key[0], 'origin': self.destination[i][0] + ',' + self.destination[i][1],
                                  'destination': self.destination[j][0] + ',' + self.destination[j][1],
                                  'city': self.city_namer,
                                  'strategy': 0}
                    res = requests.get('https://restapi.amap.com/v3/direction/transit/integrated?',
                                       params=parameters)
                    json_dic = json.loads(res.text)
                    if int(json_dic['status']) == 1:
                        ok_number = 1
                        if j != i:
                            time_list[i][j] = int(json_dic['route']['transits'][0]['duration'])  # 构造时间矩阵
                        else:
                            time_list[i][j] = 0  # numpy创建出的数组要改哪一行必须全改了不然就报错
            if ok_number == 1:
                self.road_calculate(time_list=time_list)  # 调用矩阵计算
            if ok_number == 0:
                self.result.setText("请按照要求输入经纬度或城市")
        except TypeError:
            self.result.setPlainText("请按顺序从上到下输入")




    def road_calculate(self,time_list):
        if self.count_destination == 2:
            self.road_list = [0, 1, 0, 0, 0]
            self.result.setPlainText("最短路线时间是：" + str(int(time_list[0][1] / 60)) + '分钟')
            self.get_mapfun()
            self.write_word(time=int(time_list[0][1] / 60))

        if self.count_destination == 3:
            min_time = time_list[0, 1] + time_list[1][2]
            self.road_list = [0, 1, 2, 0, 0]
            self.result.setPlainText("最短路线时间为：" + str(int(min_time / 60)) + '分钟')

            self.get_mapfun()
            self.write_word(time=int(min_time / 60))

        if self.count_destination == 4:
            time1 = time_list[0][1] + time_list[1][2] + time_list[2][3]

            time2 = time_list[0][2] + time_list[2][1] + time_list[1][3]
            if time1 < time2:
                self.result.setPlainText(
                    ' 路径为：' + self.visition[0].name1 + ' ' + self.visition[1].name1 + ' ' + self.visition[
                        2].name1 + ' ' + self.visition[3].name1 + "预计用时：" + str(int(time1 / 60)) + "分钟")
                self.road_list = [0, 1, 2, 3, 0]
                self.write_word(time=int(time1 / 60))
            if time1 > time2 or time1 == time2:
                self.result.setPlainText(
                    ' 路径为：' + self.visition[0].name1 + ' ' + self.visition[2].name1 + ' ' + self.visition[
                        1].name1 + ' ' + self.visition[3].name1 + " 预计用时：" + str(int(time2 / 60)) + "分钟")
                self.road_list = [0, 2, 1, 3, 0]
                self.write_word(time=int(time2 / 60))
            self.get_mapfun()

        if self.count_destination == 5:
            time1 = time_list[0][1] + time_list[1][2] + time_list[2][3] + time_list[3][4]
            route1 = [0, 1, 2, 3, 4]
            time1_road = [self.visition[0].name1, self.visition[1].name1, self.visition[2].name1,
                          self.visition[3].name1, self.visition[4].name1]
            time2 = time_list[0][1] + time_list[1][3] + time_list[3][2] + time_list[2][4]
            route2 = [0, 1, 3, 2, 4]
            time2_road = [self.visition[0].name1, self.visition[1].name1, self.visition[3].name1,
                          self.visition[2].name1, self.visition[4].name1]
            time3 = time_list[0][2] + time_list[2][1] + time_list[1][3] + time_list[3][4]
            route3 = [0, 2, 1, 3, 4]
            time3_road = [self.visition[0].name1, self.visition[2].name1, self.visition[1].name1,
                          self.visition[3].name1, self.visition[4].name1]
            time4 = time_list[0][2] + time_list[2][3] + time_list[3][1] + time_list[1][4]
            route4 = [0, 2, 3, 1, 4]
            time4_road = [self.visition[0].name1, self.visition[2].name1, self.visition[3].name1,
                          self.visition[1].name1, self.visition[4].name1]
            time5 = time_list[0][3] + time_list[3][1] + time_list[1][2] + time_list[2][4]
            route5 = [0, 3, 1, 2, 4]
            time5_road = [self.visition[0].name1, self.visition[3].name1, self.visition[1].name1,
                          self.visition[2].name1, self.visition[4].name1]
            time6 = time_list[0][3] + time_list[3][2] + time_list[2][1] + time_list[1][4]#计算路线用时
            route6 = [0, 3, 2, 1, 4]#保存路线信息
            time6_road = [self.visition[0].name1, self.visition[3].name1, self.visition[2].name1,
                          self.visition[1].name1, self.visition[4].name1]#保存路线名称
            time_total = [time1, time2, time3, time4, time5, time6]
            time_road = [time1_road, time2_road, time3_road, time4_road, time5_road, time6_road]
            route = [route1, route2, route3, route4, route5, route6]
            min_time = numpy.min(time_total, axis=0)#求用时最短的路线
            min_label = numpy.argmin(time_total, axis=0)
            self.road_list = route[min_label]#保存路线信息
            min_timer = str(time_road[min_label])

            self.result.setPlainText("路径为：" + min_timer + "预计用时：" + str(int(min_time / 60)) + "分钟")
            self.get_mapfun()#打印图片
            self.write_word(time=int(min_time / 60))#传入写函数


    def clear(self):
        self.count_destination=0
        self.road_list=[0,0,0,0,0]
        self.city_namer=0
        for i in range(5):
            self.visition[i].edit1=0
    def get_mapfun(self):

        key = ['a0ea2f87d4e3eb6d68c660ad7774f579']
        peramaters = {'key': key, 'location': self.destination[0][0] + ',' + self.destination[0][1], 'zoom': 10,
                      'paths': ',,,,:'}#拼接url注意paths中默认的参数都要用逗号

        if self.count_destination!=0:
            for i in range(self.count_destination):#按照最短路径数组进行遍历
                k = self.road_list[i]
                if i<self.count_destination-1:
                    peramaters['paths'] = peramaters['paths'] + self.destination[k][0] + ',' + self.destination[k][1] + ';'
                else:
                    peramaters['paths'] = peramaters['paths'] + self.destination[k][0] + ',' + self.destination[k][1]
            res = requests.get('https://restapi.amap.com/v3/staticmap?', params=peramaters)
            bytes_stream = BytesIO(res.content)#把图片转化为比特流
            #data=res.url
            # 读取到图片并加载
            roiimg = Image.open(bytes_stream)#将png转化为jpg需要先改为rgb色道
            roiimg = roiimg.convert("RGB")
            if self.self_drive.isChecked()==1:
                roiimg.save("自驾旅行图.jpg")
            else:
                roiimg.save("公交旅行图.jpg")
            #print(data)
    def creat_word(self):
        wb = openpyxl.Workbook()
        wb.create_sheet(index=0, title='路径方式')
        if self.public_transit.isChecked()==1:
            sheet = wb.worksheets[0]
            sheet['A1'].value = '起点'
            sheet['B1'].value = '终点'
            sheet['C1'].value = '时间/分钟'
            sheet['D1'].value = '费用/元'
            sheet['E1'].value = '方式'
            sheet['F1'].value = '总费用/元'
            sheet['F3'].value = '总用时/分钟'
            wb.save('公交旅行表.xlsx')
        if self.self_drive.isChecked()==1:
            sheet = wb.worksheets[0]
            sheet['A1'].value = '起点'
            sheet['B1'].value = '终点'
            sheet['C1'].value = '时间/分钟'
            sheet['D1'].value = '距离/km'
            sheet['E1'].value = '收费/元'
            sheet['F1'].value = '总用时/分钟'
            wb.save('自驾旅行表.xlsx')


    def write_word(self,time):#第一个的segment数量
        try:
            number = 2  # 记录现在写到了第几行,从第一行开始写
            if self.self_drive.isChecked() == 1:
                wb = openpyxl.load_workbook('../自驾旅行表.xlsx')
                sheet = wb.worksheets[0]
                key = ['a0ea2f87d4e3eb6d68c660ad7774f579']
                sheet['F2'].value = time  # 总用时
                for i in range(self.count_destination - 1):
                    k = self.road_list[i]  # 相邻两点起点
                    o = self.road_list[i + 1]  # 终点
                    parameters = {'key': key[0], 'origin': self.destination[k][0] + ',' + self.destination[k][1],
                                  'destination': self.destination[o][0] + ',' + self.destination[o][1]}
                    res = requests.get('https://restapi.amap.com/v3/direction/driving?',
                                       params=parameters)
                    json_dic = json.loads(res.text)
                    sheet.cell(number, 1).value = self.visition[k].name1
                    sheet.cell(number, 2).value = self.visition[o].name1  # 写上起点和终点
                    #时间
                    sheet.cell(number, 3).value = int(int(json_dic['route']['paths'][0]['duration']) / 60)
                    #距离
                    sheet.cell(number, 4).value = float(json_dic['route']['paths'][0]['distance']) / 1000
                    #费用
                    sheet.cell(number, 5).value = json_dic['route']['paths'][0]['tolls']
                    number = number + 1
                wb.save('自驾旅行表.xlsx')

            if self.public_transit.isChecked() == 1:
                wb = openpyxl.load_workbook('../公交旅行表.xlsx')
                sheet = wb.worksheets[0]
                key = ['a0ea2f87d4e3eb6d68c660ad7774f579']
                sheet['F4'].value = time  # 总用时
                money = 0
                # print("数量：" + str(self.count_destination))
                for i in range(self.count_destination - 1):
                    k = self.road_list[i]  # 相邻两点起点
                    o = self.road_list[i + 1]  # 终点
                    parameters = {'key': key[0], 'origin': self.destination[k][0] + ',' + self.destination[k][1],
                                  'destination': self.destination[o][0] + ',' + self.destination[o][1],
                                  'city': self.city_namer,
                                  'strategy': 0}
                    res = requests.get('https://restapi.amap.com/v3/direction/transit/integrated?',
                                       params=parameters)
                    json_dic = json.loads(res.text)
                    sheet.cell(number, 1).value = self.visition[k].name1
                    sheet.cell(number, 2).value = self.visition[o].name1  # 写上起点和终点
                    sheet.cell(number, 3).value = int(int(json_dic['route']['transits'][0]['duration']) / 60)
                    sheet.cell(number, 4).value = json_dic['route']['transits'][0]['cost']
                    money = money + int(float(json_dic['route']['transits'][0]['cost']))  # python无法直接将带小数点的字符串转化为整数

                    segment_length = len(json_dic['route']['transits'][0]['segments'])
                    # print("长度" + str(segment_length))
                    for j in range(segment_length):
                        if json_dic['route']['transits'][0]['segments'][j]['bus']['buslines']:
                            sheet.cell(number + j, 5).value = "乘坐： " + \
                                                              json_dic['route']['transits'][0]['segments'][j]['bus'][
                                                                  'buslines'][0]['name'] \
                                                              + " -起点：" + \
                                                              json_dic['route']['transits'][0]['segments'][j]['bus'][
                                                                  'buslines'][0]['departure_stop']['name'] + \
                                                              " -到- " + \
                                                              json_dic['route']['transits'][0]['segments'][j]['bus'][
                                                                  'buslines'][0]['arrival_stop']['name']
                        else:
                            sheet.cell(number + j, 5).value = " -步行到达终点 "

                    number = number + segment_length  # number是每一次写内容的起点
                # 总费用
                sheet['F2'] = money
                wb.save('公交旅行表.xlsx')
        except PermissionError:
            self.result.setPlainText("请先关闭相应的excel")



    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "最短路线规划"))
        self.pushButton.setText(_translate("MainWindow", "主菜单"))
        self.label.setText(_translate("MainWindow", "请输入     名称          经度        维度"))
        self.label_6.setText(_translate("MainWindow", "途经点4"))
        self.label_3.setText(_translate("MainWindow", "途经点1"))
        self.label_4.setText(_translate("MainWindow", "途经点2"))
        self.label_5.setText(_translate("MainWindow", "途经点3"))
        self.label_2.setText(_translate("MainWindow", "起点"))
        self.OK.setText(_translate("MainWindow", "确定"))
        self.cityname.setText(_translate("MainWindow", "城市："))
        self.label_7.setText(_translate("MainWindow", "注：最后一个途经点默认为终点"))
        self.groupBox.setTitle(_translate("MainWindow", "选择方式"))
        self.self_drive.setText(_translate("MainWindow", "自驾"))
        self.public_transit.setText(_translate("MainWindow", "公共交通"))
