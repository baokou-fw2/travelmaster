import os
import sys
os.environ['REQUESTS_CA_BUNDLE'] =  os.path.join(os.path.dirname(sys.argv[0]), '../cacert.pem')
import plan1
import travelerMainwindow1
import recommend1
import travel_list1
from PyQt5.QtWidgets import QApplication,QMainWindow

class controller():
    def __init__(self):
        self.pa1=0
        self.pa2=0#页面跳转变量
        self.pa3=0
        self.a=0

    def show_main(self):
        self.mainWindow = QMainWindow()
        self.u1 = travelerMainwindow1.Ui_MainWindow()
        self.u1.setupUi(self.mainWindow)

        self.u1.switch_window.connect(self.show_recommend)  # 链接两个页面
        self.u1.switch_window2.connect(self.show_plan)
        self.u1.switch_window3.connect(self.show_travelerlist)



        self.mainWindow.show()




    def show_recommend(self):
        self.Window2 = QMainWindow()
        self.u2 = recommend1.Ui_MainWindow()
        self.u2.setupUi(self.Window2)
        self.mainWindow.close()
        self.Window2.show()
        self.u2.switch_window3.connect(self.show_main)


    def show_plan(self):
        self.Window3=QMainWindow()
        self.u3= plan1.Ui_MainWindow()
        self.u3.setupUi(self.Window3)
        self.mainWindow.close()
        self.Window3.show()
        self.u3.switch_window4.connect(self.show_main)

    def show_travelerlist(self):
        self.Window4=QMainWindow()
        self.u4= travel_list1.Ui_MainWindow()
        self.u4.setupUi(self.Window4)
        self.mainWindow.close()
        self.Window4.show()
        self.u4.switch_window4.connect(self.show_main)


def main():
    app = QApplication(sys.argv)
    Controller = controller()
    Controller.show_main()
    sys.exit(app.exec_())

if __name__=='__main__':
    main()


