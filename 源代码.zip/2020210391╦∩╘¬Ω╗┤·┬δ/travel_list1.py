# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'travel_list.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtWidgets
import mafengwo
class Ui_MainWindow(QtCore.QObject):
    switch_window4 = QtCore.pyqtSignal()
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("城市旅游信息查询")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.back = QtWidgets.QPushButton(self.centralwidget)
        self.back.setGeometry(QtCore.QRect(20, 30, 93, 28))
        self.back.setObjectName("back")
        self.lineEdit_2 = QtWidgets.QTextEdit(self.centralwidget)
        self.lineEdit_2.setGeometry(QtCore.QRect(120, 110, 461, 301))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(121, 60, 385, 30))
        self.widget.setObjectName("widget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.widget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_2 = QtWidgets.QLabel(self.widget)
        self.label_2.setObjectName("label_2")
        self.horizontalLayout.addWidget(self.label_2)
        self.city_name = QtWidgets.QLineEdit(self.widget)
        self.city_name.setObjectName("city_name")
        self.horizontalLayout.addWidget(self.city_name)
        self.browse_button = QtWidgets.QPushButton(self.widget)
        self.browse_button.setObjectName("browse_button")
        self.horizontalLayout.addWidget(self.browse_button)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
#-------------------------fenjiexian
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.back.clicked.connect(self.switch)
        self.browse_button.clicked.connect(self.zhanshi)

    def switch(self):
        self.switch_window4.emit()

    def zhanshi(self):
        try:
            data = mafengwo.spiders_search(city_name=self.city_name.text())
            self.lineEdit_2.setPlainText(
                "城市概述：" + '\n' + str(data[0]) + '\n' + '前五景点：' + '\n' + str(data[2]) + '\n' + '五个景点的评论个数：' + '\n' + str(
                    data[1]) + '\n' + '景点概述：' + '\n' + str(data[3])
                + '\n' + str(data[4]) + '\n' + str(data[5]) + '\n' + str(data[6]) + '\n' + str(data[7]))
        except IndexError:
            self.lineEdit_2.setText("请输入正确的城市名称")

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "城市旅游信息查询"))
        self.back.setText(_translate("MainWindow", "主菜单"))
        self.label_2.setText(_translate("MainWindow", "请输入城市名称"))
        self.browse_button.setText(_translate("MainWindow", "搜索"))

