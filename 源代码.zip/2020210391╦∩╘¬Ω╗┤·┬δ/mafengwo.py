import bs4
from bs4 import BeautifulSoup
import re
import urllib
from urllib import request,error,response
import  xlwt
import requests

def spiders_search(city_name):
    all_data=[]
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.41 Safari/537.36 Edg/101.0.1210.32'}
    url = 'https://www.mafengwo.cn/search/q.php?q='+city_name+'&seid=B8E27F5A-1DFC-48A1-AA19-7E3373AC730D'
    response = requests.get(url, headers=headers)#构建网络爬虫
    html = response.content
    bs = BeautifulSoup(html, "html.parser")#解析网页内容
    data_list = bs.select(".head-link")  # 通过类名查找
    s = str(data_list)  # 返回的是一个resultset类型的数组，可见热门景点的连接在第二个

    find_re0=re.compile(r'<a href="(.*?)"')
    url2=re.findall(find_re0,s)

    response2 = requests.get(url2[0], headers=headers, timeout=5)
    html2 = response2.content
    #print(response2.status_code)
    bs2 = BeautifulSoup(html2, "html.parser")
    data_list2 = bs2.find_all('div', class_="wrapper")
    data = str(data_list2[1])  # 转为字符串
    find_re1 = re.compile(r'<span id="mdd_poi_desc">(.*?)</span>',re.S)  # 构建正则表达式，左侧为开头右侧为结尾，注意r
    detail = re.findall(find_re1, data)  # 调用函数查找，得到所需城市概况
    all_data.append(detail)
    #print(detail)
    if all_data[0]:#有的景区不存在detail
        data2 = str(data_list2[2])  # 爬取名称
    else:
        data2=str(data_list2[1])
    find_re2 = re.compile(r'<span class="rev-total"><em>(.*?)</em> 条点评</span>')
    number_detail = re.findall(find_re2, data2)  # 点评数量
    all_data.append(number_detail)
    #print(number_detail)
    find_re3 = re.compile(r'<a href="/poi/.*title="(.*?)">')
    name_detail = re.findall(find_re3, data2)
    number = len(name_detail)  # 返回的是三个三个重复的poi名称需要进行重新整合赋值
    length_1 = int(number / 3)
    name_detail_list = []
    url_detail_list=[]
    for j in range(length_1):
        name_detail_list.append(name_detail[j * 3])
    url_list=[]
    for i in range(5):
        find_url = re.compile(r'<a href="(.*?)" target="_blank" title="'+name_detail_list[i])
        url_list.append(re.findall(find_url, data2))
        url_detail_list.append(url_list[i][0])
    all_data.append(name_detail_list)
    for j in range(length_1):
        url3 = 'https://baike.baidu.com/item/' + name_detail_list[j]
        response3 = requests.get(url3, headers=headers, timeout=5)
        html3 = response3.content
        #print(response3.status_code)
        bs_baidu = BeautifulSoup(html3, "html.parser")
        data3 = str(bs_baidu)  # 通过类名查找
        find_re4 = re.compile(r'<meta content="(.*?)" name="description"/>')
        content_detail = re.findall(find_re4, data3)
        if content_detail:
            content_detail.append("请前往查看详情：https://www.mafengwo.cn"+str(url_detail_list[j]))
            all_data.append(content_detail)
        else:
            all_data.append("请前往查看详情：https://www.mafengwo.cn"+url_detail_list[j])
    if all_data[0]==[]:
        all_data[0]=["马蜂窝旅游网暂无该城市旅游信息简介!"]

    return all_data











